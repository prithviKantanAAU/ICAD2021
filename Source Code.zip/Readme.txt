To get the program running, create a JUCE plugin project called 'STSInteraction' and import the C++ code into:
A) The source folder via the Projucer
B) The source folder via the file explorer

Enable the juce_osc module and check "Plugin is a Synth" in the Projucer settings for the project.

Save and open the project solution and build it, it ought to run barring some version incompatibilities. The algorithms for movement detection and mapping are in

- MovementAnalysis.h
- MusicControl.h
- MusicInfoCompute.h

To load the mapping presets in the interface, place the folder containing the presets in the Standalone Plugin folder after building the project.

Note that this is the version of the framework as of March 2021, described in the ICAD2021 paper. For the latest version of the framework, please contact:

Prithvi Ravi Kantan
prka@create.aau.dk